cd ~/RS-Kassa
rm RS-Kassa.gambas
wget http://rosa.allunix.ru/kkm/RS-Kassa.gambas
chmod 777 RS-Kassa.gambas
cd ..
